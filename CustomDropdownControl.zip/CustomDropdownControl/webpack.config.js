const path = require('path');

module.exports = {
  entry: './src/index.tsx',
  mode: 'production',
  output: {
    filename: 'ControlBundle.js',
    path: path.resolve(__dirname, 'pcftools'),
    libraryTarget: 'umd',
    globalObject: 'this'
  },
  resolve: {
    extensions: ['.ts', '.tsx', '.js']
  },
  module: {
    rules: [
      {
        test: /\.tsx?$/, // Regex escaped in JSON
        use: 'ts-loader',
        exclude: /node_modules/
      },
      {
        test: /\.css$/i,
        use: ['style-loader', 'css-loader'],
      }
    ]
  }
};
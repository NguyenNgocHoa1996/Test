// src/index.tsx
import { IInputs, IOutputs } from "./generated/ManifestTypes";
import React from "react";
import ReactDOM from "react-dom";
import CustomDropdownControl from "./CustomDropdownControl";

export class CustomDropdownControl
  implements ComponentFramework.ReactControl<IInputs, IOutputs>
{
  private theContainer: HTMLDivElement;
  private props: IInputs;

  constructor() {}

  public init(
    context: ComponentFramework.Context<IInputs>,
    notifyOutputChanged: () => void,
    state: ComponentFramework.Dictionary,
    container: HTMLDivElement
  ): void {
    this.theContainer = container;
    this.props = context.parameters;
  }

  public updateView(context: ComponentFramework.Context<IInputs>): void {
    this.props = context.parameters;
    ReactDOM.render(
      <CustomDropdownControl {...this.props} />, 
      this.theContainer
    );
  }

  public getOutputs(): IOutputs {
    return {
      selectedValue: this.props.selectedValue.raw || "",
    };
  }

  public destroy(): void {
    ReactDOM.unmountComponentAtNode(this.theContainer);
  }
}
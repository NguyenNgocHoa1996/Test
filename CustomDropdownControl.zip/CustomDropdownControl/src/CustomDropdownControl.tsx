// src/CustomDropdownControl.tsx
import React, { useState, useEffect } from 'react';
import { IInputs, IOutputs } from './generated/ManifestTypes';
import { Select, Modal, Button } from 'antd';
import 'antd/dist/reset.css';
import './styles/CustomDropdownControl.css';

const { Option } = Select;

const statusColors: { [key: string]: string } = {
  Success: 'green',
  Pending: 'orange',
  Error: 'red',
};

const CustomDropdownControl: React.FC<IInputs> = (props) => {
  const [options, setOptions] = useState<string[]>([]);
  const [filteredOptions, setFilteredOptions] = useState<string[]>([]);
  const [selected, setSelected] = useState<string>('');
  const [isModalVisible, setIsModalVisible] = useState<boolean>(false);

  useEffect(() => {
    if (props.options.raw) {
      const parsedOptions = props.options.raw.split(',');
      setOptions(parsedOptions);
      setFilteredOptions(parsedOptions);
    }
  }, [props.options]);

  const handleChange = (value: string) => {
    setSelected(value);
    setIsModalVisible(true);
    props.onChange && props.onChange();
    props.selectedValue.setValue(value);
  };

  const handleSearch = (value: string) => {
    const filtered = options.filter((option) =>
      option.toLowerCase().includes(value.toLowerCase())
    );
    setFilteredOptions(filtered);
  };

  const handleOk = () => {
    setIsModalVisible(false);
  };

  const getColor = (value: string) => {
    return statusColors[value] || 'blue';
  };

  return (
    <>
      <Select
        showSearch
        placeholder="Select an option"
        onChange={handleChange}
        onSearch={handleSearch}
        filterOption={false}
        style={{ width: 200 }}
      >
        {filteredOptions.map((option) => (
          <Option key={option} value={option}>
            {option}
          </Option>
        ))}
      </Select>
      <Modal
        title={selected}
        visible={isModalVisible}
        onOk={handleOk}
        onCancel={handleOk}
        footer=[
          <Button key="ok" type="primary" onClick={handleOk}>
            OK
          </Button>,
        ]
        style={{ textAlign: 'center' }}
        bodyStyle={{ backgroundColor: getColor(selected), color: 'white' }}
      >
        You selected: {selected}
      </Modal>
    </>
  );
};

export default CustomDropdownControl;
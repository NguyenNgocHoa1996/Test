import * as React from "react";
import * as ReactDOM from "react-dom";
import { IInputs } from "../generated/ManifestTypes";
import Dialog from "./Dialog";

interface DropdownDialogProps {
    options: string[];
    selectedValue: string;
    onChange: (value: string) => void;
}

interface DropdownDialogState {
    showDialog: boolean;
    dialogColor: string;
}

export class DropdownDialogControl {
    private context: ComponentFramework.Context<IInputs>;
    private notifyOutputChanged: () => void;
    private props: DropdownDialogProps;
    private container: HTMLDivElement;
    private selectedValue: string = "";

    constructor(context: ComponentFramework.Context<IInputs>, notifyOutputChanged: () => void) {
        this.context = context;
        this.notifyOutputChanged = notifyOutputChanged;
    }

    public render(container: HTMLDivElement): void {
        this.container = container;
        this.selectedValue = this.context.parameters.SelectedValue.raw || "";
        this.props = {
            options: this.parseOptions(this.context.parameters.Options.raw),
            selectedValue: this.selectedValue,
            onChange: this.handleChange.bind(this)
        };
        ReactDOM.render(<DropdownDialog {...this.props} />, this.container);
    }

    public updateProps(context: ComponentFramework.Context<IInputs>): void {
        this.context = context;
        const newValue = this.context.parameters.SelectedValue.raw || "";
        if (newValue !== this.selectedValue) {
            this.selectedValue = newValue;
            this.props.selectedValue = this.selectedValue;
            ReactDOM.render(<DropdownDialog {...this.props} />, this.container);
        }
    }

    public getSelectedValue(): any {
        return this.selectedValue;
    }

    public unmount(): void {
        ReactDOM.unmountComponentAtNode(this.container);
    }

    private parseOptions(optionsRaw: string | null): string[] {
        if (!optionsRaw) return [];
        return optionsRaw.split(",").map(opt => opt.trim());
    }

    private handleChange(value: string): void {
        this.selectedValue = value;
        ReactDOM.render(<DropdownDialog {...this.props} />, this.container);
        this.notifyOutputChanged();
    }
}

const DropdownDialog: React.FC<DropdownDialogProps> = ({ options, selectedValue, onChange }) => {
    const [showDialog, setShowDialog] = React.useState(false);
    const [dialogColor, setDialogColor] = React.useState<string>("">

    const handleSelectionChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
        const value = event.target.value;
        onChange(value);
        setDialogColor(getColor(value));
        setShowDialog(true);
    };

    const closeDialog = () => {
        setShowDialog(false);
    };

    const getColor = (value: string): string => {
        switch (value.toLowerCase()) {
            case "success":
                return "green";
            case "pending":
                return "yellow";
            case "error":
                return "red";
            default:
                return "blue";
        }
    };

    return (
        <div>
            <select value={selectedValue} onChange={handleSelectionChange}>
                <option value="">-- Select --</option>
                {options.map(opt => (
                    <option key={opt} value={opt}>{opt}</option>
                ))}
            </select>
            {showDialog && (
                <Dialog color={dialogColor} onClose={closeDialog} message={selectedValue} />
            )}
        </div>
    );
};
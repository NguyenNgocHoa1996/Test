import * as React from "react";

interface DialogProps {
    color: string;
    message: string;
    onClose: () => void;
}

const Dialog: React.FC<DialogProps> = ({ color, message, onClose }) => {
    return (
        <div className="dialog-overlay">
            <div className="dialog-box" style={{ borderColor: color }}>
                <p>{message}</p>
                <button onClick={onClose}>OK</button>
            </div>
        </div>
    );
};

export default Dialog;
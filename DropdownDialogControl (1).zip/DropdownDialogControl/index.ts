import { IInputs, IOutputs } from "./generated/ManifestTypes";
import { DropdownDialogControl } from "./src/DropdownDialogControl";

export class DropdownDialogControlWrapper implements ComponentFramework.StandardControl<IInputs, IOutputs> {
    private reactControl: DropdownDialogControl;
    private container: HTMLDivElement;

    constructor() {}

    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        state: ComponentFramework.Dictionary,
        container: HTMLDivElement
    ): void {
        this.container = container;
        this.reactControl = new DropdownDialogControl(context, notifyOutputChanged);
        this.reactControl.render(this.container);
    }

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        this.reactControl.updateProps(context);
    }

    public getOutputs(): IOutputs {
        return {
            SelectedValue: this.reactControl.getSelectedValue()
        };
    }

    public destroy(): void {
        this.reactControl.unmount();
    }
}
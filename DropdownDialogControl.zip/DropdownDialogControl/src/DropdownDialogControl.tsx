import React, { useState } from 'react';
import { Select, Modal, Button } from 'antd';

const { Option } = Select;

interface DropdownDialogControlProps {
    options: string[];
    selectedValue: string;
    onChange: (value: string) => void;
}

const DropdownDialogControl: React.FC<DropdownDialogControlProps> = ({ options, selectedValue, onChange }) => {
    const [isModalVisible, setIsModalVisible] = useState(false);
    const [currentValue, setCurrentValue] = useState(selectedValue);
    const [filteredOptions, setFilteredOptions] = useState(options);

    const handleSelectChange = (value: string) => {
        setCurrentValue(value);
        onChange(value);
        setIsModalVisible(true);
    };

    const handleOk = () => {
        setIsModalVisible(false);
    };

    const getColor = (value: string) => {
        switch(value) {
            case 'Success':
                return 'green';
            case 'Pending':
                return 'orange';
            case 'Error':
                return 'red';
            default:
                return 'blue';
        }
    };

    const handleSearch = (value: string) => {
        const filtered = options.filter(option => option.toLowerCase().includes(value.toLowerCase()));
        setFilteredOptions(filtered);
    };

    return (
        <>
            <Select
                showSearch
                placeholder="Select an option"
                optionFilterProp="children"
                onChange={handleSelectChange}
                onSearch={handleSearch}
                value={currentValue}
                style={{ width: 200 }}
                filterOption={false}
            >
                {filteredOptions.map(option => (
                    <Option key={option} value={option}>
                        {option}
                    </Option>
                ))}
            </Select>
            <Modal
                title="Selected Value"
                visible={isModalVisible}
                onOk={handleOk}
                onCancel={handleOk}
                footer={[
                    <Button key="ok" type="primary" onClick={handleOk}>
                        OK
                    </Button>,
                ]}
                bodyStyle={{ backgroundColor: getColor(currentValue), color: 'white' }}
            >
                <p>You selected: {currentValue}</p>
            </Modal>
        </>
    );
};

export default DropdownDialogControl;
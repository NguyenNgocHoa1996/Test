import { IInputs, IOutputs } from "./generated/ManifestTypes";
import React from 'react';
import ReactDOM from 'react-dom';
import DropdownDialogControl from './DropdownDialogControl';

export class DropdownDialogControlImpl implements ComponentFramework.StandardControl<IInputs, IOutputs> {
    private container: HTMLDivElement;
    private notifyOutputChanged: () => void;
    private selectedValue: string;

    constructor() {}

    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        state: ComponentFramework.Dictionary,
        container: HTMLDivElement
    ): void {
        this.container = container;
        this.notifyOutputChanged = notifyOutputChanged;
        this.selectedValue = context.parameters.selectedValue.raw || "";

        ReactDOM.render(
            <DropdownDialogControl
                options={JSON.parse(context.parameters.options.raw || '[]')}
                selectedValue={this.selectedValue}
                onChange={this.onChange.bind(this)}
            />, 
            this.container
        );
    }

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        this.selectedValue = context.parameters.selectedValue.raw || "";
        ReactDOM.render(
            <DropdownDialogControl
                options={JSON.parse(context.parameters.options.raw || '[]')}
                selectedValue={this.selectedValue}
                onChange={this.onChange.bind(this)}
            />, 
            this.container
        );
    }

    public getOutputs(): IOutputs {
        return {
            selectedValue: this.selectedValue
        };
    }

    public destroy(): void {
        ReactDOM.unmountComponentAtNode(this.container);
    }

    private onChange(value: string): void {
        this.selectedValue = value;
        this.notifyOutputChanged();
    }
}
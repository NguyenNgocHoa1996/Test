import React from 'react';
import { Modal, Button } from 'antd';

interface DialogComponentProps {
    visible: boolean;
    value: string;
    onClose: () => void;
}

const DialogComponent: React.FC<DialogComponentProps> = ({ visible, value, onClose }) => {
    const getColor = (value: string) => {
        switch(value) {
            case 'Success':
                return 'green';
            case 'Pending':
                return 'orange';
            case 'Error':
                return 'red';
            default:
                return 'blue';
        }
    };

    return (
        <Modal
            title="Selected Value"
            visible={visible}
            onOk={onClose}
            onCancel={onClose}
            footer={[
                <Button key="ok" type="primary" onClick={onClose}>
                    OK
                </Button>,
            ]}
            bodyStyle={{ backgroundColor: getColor(value), color: 'white' }}
        >
            <p>You selected: {value}</p>
        </Modal>
    );
};

export default DialogComponent;
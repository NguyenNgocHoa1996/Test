const path = require('path');

module.exports = {
  entry: './src/index.ts',
  output: {
    filename: 'DropdownDialogControl.bundle.js',
    path: path.resolve(__dirname, 'dist'),
    libraryTarget: 'amd',
    library: 'DropdownDialogControl'
  },
  resolve: {
    extensions: ['.ts', '.tsx', '.js']
  },
  externals: ['react', 'react-dom', 'antd'],
  module: {
    rules: [
      {
        test: /\.tsx?$/,
        use: 'ts-loader',
        exclude: /node_modules/,
      },
      {
        test: /\.css$/,
        use: ['style-loader', 'css-loader'],
      }
    ]
  }
};
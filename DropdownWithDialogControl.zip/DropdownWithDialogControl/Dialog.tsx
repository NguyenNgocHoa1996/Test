import * as React from "react";
import "./styles.css";

interface DialogProps {
    option: string;
    onClose: () => void;
}

const Dialog: React.FC<DialogProps> = ({ option, onClose }) => {
    let dialogStyle = {};

    switch (option) {
        case "Success":
            dialogStyle = { borderLeft: "5px solid green" };
            break;
        case "Pending":
            dialogStyle = { borderLeft: "5px solid orange" };
            break;
        case "Error":
            dialogStyle = { borderLeft: "5px solid red" };
            break;
        default:
            dialogStyle = { borderLeft: "5px solid gray" };
    }

    return (
        <div className="dialog-overlay">
            <div className="dialog" style={dialogStyle}>
                <p>You selected: <strong>{option}</strong></p>
                <button onClick={onClose} className="dialog-button">OK</button>
            </div>
        </div>
    );
};

export default Dialog;
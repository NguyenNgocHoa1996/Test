import { IInputs, IOutputs } from "./generated/ManifestTypes";
import * as React from "react";
import * as ReactDOM from "react-dom";
import DropdownControl from "./DropdownControl";
import Dialog from "./Dialog";

export class DropdownWithDialogControl implements ComponentFramework.StandardControl<IInputs, IOutputs> {
    private container: HTMLDivElement;
    private notifyOutputChanged: () => void;
    private selectedOption: string;
    private dialogVisible: boolean;
    private context: ComponentFramework.Context<IInputs>;

    constructor() {
        this.selectedOption = "";
        this.dialogVisible = false;
    }

    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        state: ComponentFramework.Dictionary,
        container: HTMLDivElement
    ): void {
        this.context = context;
        this.notifyOutputChanged = notifyOutputChanged;
        this.container = container;

        ReactDOM.render(
            <DropdownControl
                selectedOption={this.selectedOption}
                onChange={this.handleChange}
            />,
            this.container
        );
    }

    private handleChange = (newValue: string) => {
        this.selectedOption = newValue;
        this.dialogVisible = true;
        this.notifyOutputChanged();

        ReactDOM.render(
            <React.Fragment>
                <DropdownControl
                    selectedOption={this.selectedOption}
                    onChange={this.handleChange}
                />
                {this.dialogVisible && (
                    <Dialog
                        option={this.selectedOption}
                        onClose={this.closeDialog}
                    />
                )}
            </React.Fragment>,
            this.container
        );
    };

    private closeDialog = () => {
        this.dialogVisible = false;
        ReactDOM.render(
            <DropdownControl
                selectedOption={this.selectedOption}
                onChange={this.handleChange}
            />,
            this.container
        );
    };

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        // Update logic if necessary
    }

    public getOutputs(): IOutputs {
        return {
            selectedOption: this.selectedOption
        };
    }

    public destroy(): void {
        ReactDOM.unmountComponentAtNode(this.container);
    }
}
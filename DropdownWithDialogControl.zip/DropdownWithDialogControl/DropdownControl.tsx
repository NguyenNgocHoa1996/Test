import * as React from "react";
import "./styles.css";

interface DropdownControlProps {
    selectedOption: string;
    onChange: (value: string) => void;
}

const DropdownControl: React.FC<DropdownControlProps> = ({ selectedOption, onChange }) => {
    const options = ["Success", "Pending", "Error"];

    const handleSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        onChange(e.target.value);
    };

    return (
        <div className="dropdown-container">
            <label htmlFor="custom-dropdown">Select Status:</label>
            <select
                id="custom-dropdown"
                value={selectedOption}
                onChange={handleSelectChange}
                className="custom-dropdown"
            >
                <option value="">-- Select --</option>
                {options.map((option) => (
                    <option key={option} value={option}>{option}</option>
                ))}
            </select>
        </div>
    );
};

export default DropdownControl;